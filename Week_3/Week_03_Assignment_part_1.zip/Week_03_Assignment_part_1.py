#   FILE:   Week_03_Assignment_part_1.py
#   DATE:   2021-09-09
#   AUTHOR: Tyler Hand
#   DESCRIPTION: 
"""
this is the week_03_assignment_part_1.

"""

import sys

# A constant for the number of characters across the console
CONSOLE_WIDTH = 80

def main(argv):
    """
    Description of main() goes here.

    INPUTS:
        argv A list of strings representing the command line arguments

    RETURNS:
        None
    """
    # Show the program title
    program_title = "*** Week 3 Assingnment part 1  ***"
    print(f'\n{program_title:^{CONSOLE_WIDTH}}')
    # Get the inputs
    
    # Perform Processing

    Name = 'Tyler Hand'
    adress = '300 N Main Ave, Alburnett IA, 52202'
    phone_number = '319-432-1104'
    course = 'Computer Soffware Devlopment'

    # Display the outputs

    print(f"\n {Name} | {adress} | {phone_number} | {course} |")
     
    # Let the use know the program is done
    
    

# Call main()
if __name__ == "__main__":
    main(sys.argv)